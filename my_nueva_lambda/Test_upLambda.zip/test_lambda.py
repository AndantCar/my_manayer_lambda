#!/usr/bin/python3
# -*- encoding:utf-8 -*-

__author__ = 'Carlos Añorve'
__version__ = '1.0'


def main_2(event, context):
    del event
    del context
    return 'ok'





